import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from flask import Flask, jsonify
from flask_pymongo import PyMongo

from bson import ObjectId
from app import app, mongo, format_response  
from bson import ObjectId
from datetime import datetime, timedelta

from flask import session

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['MONGO_URI'] = 'mongodb://localhost:27017/test_evoting'  # use a separate test database
    client = app.test_client()
    with app.app_context():
        # Initialize the database or reset it for tests
        mongo.db.voters.drop()
        mongo.db.admins.drop()
        mongo.db.candidates.drop()
        mongo.db.elections.drop()
    yield client
    # Cleanup after tests
    mongo.db.voters.drop()
    mongo.db.admins.drop()
    mongo.db.candidates.drop()
    mongo.db.elections.drop()

# Test MongoDB connection
def test_db_connection(client):
    response = client.get('/test_db')
    assert b"MongoDB is connected" in response.data

# Test: Verify voter can only cast one vote per election


def test_unauthorized_vote_casting(client):
    # Setup: Mock admin login, create candidate, register voter, and create election
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    candidate = mongo.db.candidates.insert_one({"name": "Candidate 1", "party": "Party A"})
    mongo.db.voters.insert_one({"name": "Voter", "cnic": "987654321", "dob": "1990-01-01", "age": 30, "voted": False})

    start_date = datetime.now() - timedelta(days=1)
    end_date = datetime.now() + timedelta(days=1)
    election_id = mongo.db.elections.insert_one({
        "name": "Election 2024",
        "start_date": start_date,
        "end_date": end_date,
        "votes": {}
    }).inserted_id

    # Clear the session to ensure no user is logged in
    with client.session_transaction() as sess:
        sess.clear()

    # Try to cast vote without login
    response = client.post('/cast_vote', json={"election_id": str(election_id), "candidate_id": str(candidate.inserted_id)})

    # Check for redirect (302 status code) and ensure it redirects to the login page
    assert response.status_code == 302
    assert response.location.endswith('/login_page')  # Check the relative URL


# Test: Invalid credentials during vote casting
def test_invalid_credentials_for_vote(client):
    # Mock admin login and create a candidate
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    candidate = mongo.db.candidates.insert_one({"name": "Candidate 1", "party": "Party A"})

    # Register a voter
    mongo.db.voters.insert_one({"name": "Voter", "cnic": "987654321", "dob": "1990-01-01", "age": 30, "voted": False})

    # Try to login with invalid credentials
    response = client.post('/login', json={"cnic": "00000", "dob": "1990-01-01"})
    data = response.get_json()

    assert response.status_code == 200
    assert data["success"] is False
    assert data["message"] == "Invalid credentials"

def test_vote_casting_invalid_election_or_candidate(client):
    # Setup: Mock admin login, create a candidate
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Create fake invalid election and candidate IDs
    election_id = str(ObjectId())  # Invalid election_id
    candidate_id = str(ObjectId())  # Invalid candidate_id

    # Try to cast vote with invalid election or candidate
    response = client.post('/cast_vote', json={"election_id": election_id, "candidate_id": candidate_id})
    data = response.get_json()

    # Check for error message related to invalid election or candidate
    assert response.status_code == 200
    assert data["success"] is False
    assert data["message"] == "Admins are not allowed to cast votes."


def test_cast_vote_invalid_voter(client):
    # Simulate login for a non-existent voter
    login_response = client.post('/login', json={'cnic': 'invalid_cnic', 'dob': '1990-01-01'})
    login_json = login_response.get_json()

    # Ensure login failed
    assert login_json['success'] == False
    assert login_json['message'] == "Invalid credentials"

    # Try to cast vote with an invalid voter ID (not logged in)
    response = client.post('/cast_vote', json={
        "election_id": "some_valid_election_id",  # Use valid election ID
        "candidate_id": "some_valid_candidate_id"  # Use valid candidate ID
    })

    # Check for redirect (302 status code) and ensure it redirects to the login page
    assert response.status_code == 302
    assert response.location.endswith('/login_page')  # Check the relative URL


def test_cast_vote_already_voted(client):
    # Setup: Insert a voter who has already voted
    voter_data = {"name": "John Doe", "cnic": "12345", "dob": "2000-01-01", "age": 24, "voted": True}
    voter = mongo.db.voters.insert_one(voter_data)

    candidate_data = {"name": "Candidate A", "party": "Party X"}
    candidate = mongo.db.candidates.insert_one(candidate_data)

    election_data = {
        "name": "Election 2024", 
        "start_date": datetime.now() - timedelta(minutes=5), 
        "end_date": datetime.now() + timedelta(minutes=5),
        "votes": {}
    }
    election = mongo.db.elections.insert_one(election_data)

    # Simulate login by setting session
    with client.session_transaction() as sess:
        sess['user'] = {"id": str(voter.inserted_id), "role": "voter"}

    # Request: Cast vote
    response = client.post('/cast_vote', json={
        "election_id": str(election.inserted_id),
        "candidate_id": str(candidate.inserted_id)
    })

    # Assertions: Voter has already voted, should fail
    assert response.status_code == 200
    assert response.json['success'] is False
    assert response.json['message'] == "Voter has already cast a vote."
