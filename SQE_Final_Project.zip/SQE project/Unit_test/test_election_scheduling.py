import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime

# Assuming the Flask app is named 'app'
from app import app
from bson import ObjectId  # Import ObjectId

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client


# Test creating an election
@patch('app.mongo')
def test_create_election(mock_mongo, client):
    # Mock the elections collection
    elections_collection = MagicMock()
    mock_mongo.db.elections = elections_collection

    # Scenario 1: Admin user creates an election
    with client.session_transaction() as session:
        session['user'] = {'role': 'admin'}  # Simulate admin login

    election_data = {
        'name': 'Presidential Election',
        'start_date': '2024-05-01T08:00:00',
        'end_date': '2024-05-02T08:00:00'
    }

    # Send request to create election
    response = client.post('/create_election', json=election_data)

    # Assert that the election was created successfully
    assert response.status_code == 200
    assert b'Election created successfully.' in response.data

    # Verify that insert_one was called with correct data
    elections_collection.insert_one.assert_called_once_with({
        'name': 'Presidential Election',
        'start_date': datetime.fromisoformat('2024-05-01T08:00:00'),
        'end_date': datetime.fromisoformat('2024-05-02T08:00:00'),
        'votes': {}
    })


# Test create election with invalid date range (start_date >= end_date)
@patch('app.mongo')
def test_create_election_invalid_dates(mock_mongo, client):
    # Mock the elections collection
    elections_collection = MagicMock()
    mock_mongo.db.elections = elections_collection

    # Scenario 2: Admin user creates election with invalid dates
    with client.session_transaction() as session:
        session['user'] = {'role': 'admin'}  # Simulate admin login

    election_data = {
        'name': 'Presidential Election',
        'start_date': '2024-05-02T08:00:00',
        'end_date': '2024-05-01T08:00:00'
    }

    # Send request to create election with invalid dates
    response = client.post('/create_election', json=election_data)

    # Assert that the response indicates an error
    assert response.status_code == 200
    assert b'Invalid election schedule.' in response.data


# Test creating an election by a non-admin user
@patch('app.mongo')
def test_create_election_not_admin(mock_mongo, client):
    # Mock the elections collection
    elections_collection = MagicMock()
    mock_mongo.db.elections = elections_collection

    # Scenario 3: Non-admin user tries to create an election
    with client.session_transaction() as session:
        session['user'] = {'role': 'user'}  # Simulate non-admin user login

    election_data = {
        'name': 'Presidential Election',
        'start_date': '2024-05-01T08:00:00',
        'end_date': '2024-05-02T08:00:00'
    }

    # Send request to create election
    response = client.post('/create_election', json=election_data)

    # Assert that the user is redirected to login
    assert response.status_code == 302  # Redirect
    assert 'login_page' in response.location  # Check if redirected to login page


@patch('app.mongo')
def test_delete_election(mock_mongo, client):
    # Mock the elections collection
    elections_collection = MagicMock()
    mock_mongo.db.elections = elections_collection

    # Scenario 1: Admin user deletes an election
    with client.session_transaction() as session:
        session['user'] = {'role': 'admin'}  # Simulate admin login

    election_id = '63c9f150e8e4b6e3bd4d5f0c'  # Example valid ObjectId
    election_id_object = ObjectId(election_id)  # Convert to ObjectId

    # Mock the deletion result
    elections_collection.delete_one.return_value.deleted_count = 1

    # Send request to delete the election
    response = client.delete(f'/delete_election/{election_id}')

    # Assert that the election was deleted successfully
    assert response.status_code == 200
    assert b'Election deleted successfully.' in response.data

    # Verify that delete_one was called with the correct ObjectId
    elections_collection.delete_one.assert_called_once_with({"_id": election_id_object})

# Test deleting an election with invalid election ID
@patch('app.mongo')
def test_delete_election_invalid_id(mock_mongo, client):
    # Mock the elections collection
    elections_collection = MagicMock()
    mock_mongo.db.elections = elections_collection

    # Scenario 2: Admin user tries to delete election with invalid ID
    with client.session_transaction() as session:
        session['user'] = {'role': 'admin'}  # Simulate admin login

    invalid_election_id = 'invalid_id'

    # Send request to delete election with invalid ID
    response = client.delete(f'/delete_election/{invalid_election_id}')

    # Assert that the response indicates an error due to invalid ID
    assert response.status_code == 200
    assert b'Invalid election ID.' in response.data


# Test deleting an election by a non-admin user
@patch('app.mongo')
def test_delete_election_not_admin(mock_mongo, client):
    # Mock the elections collection
    elections_collection = MagicMock()
    mock_mongo.db.elections = elections_collection

    # Scenario 3: Non-admin user tries to delete an election
    with client.session_transaction() as session:
        session['user'] = {'role': 'user'}  # Simulate non-admin user login

    election_id = '63c9f150e8e4b6e3bd4d5f0c'  # Example valid ObjectId

    # Send request to delete election
    response = client.delete(f'/delete_election/{election_id}')

    # Assert that the user is redirected to login
    assert response.status_code == 302  # Redirect
    assert 'login_page' in response.location  # Check if redirected to login page
