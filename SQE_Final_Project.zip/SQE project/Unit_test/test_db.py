import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from app import app, mongo
from flask import session
# Fixture to mock MongoDB
@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['MONGO_URI'] = 'mongodb://localhost:27017/test_evoting'  # use a separate test database
    client = app.test_client()
    with app.app_context():
        # Initialize the database or reset it for tests
        mongo.db.voters.drop()
        mongo.db.admins.drop()
        mongo.db.candidates.drop()
        mongo.db.elections.drop()
    yield client
    # Cleanup after tests
    mongo.db.voters.drop()
    mongo.db.admins.drop()
    mongo.db.candidates.drop()
    mongo.db.elections.drop()

# Test MongoDB connection
    # Mock session login
   

# Test: Register a voter
def test_register_voter(client):
    # Mock admin login
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    
    # Admin login
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Register a new voter
    response = client.post('/register_voter', json={"name": "John Doe", "cnic": "123456789", "dob": "1990-01-01", "age": 30})
    data = response.get_json()

    assert response.status_code == 200
    assert data["success"] is True
    assert data["message"] == "Voter registered successfully."

def test_register_voter_already_exists(client):
    # Mock admin login
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Register a new voter
    mongo.db.voters.insert_one({"name": "John Doe", "cnic": "123456789", "dob": "1990-01-01", "age": 30})

    response = client.post('/register_voter', json={"name": "Jane Doe", "cnic": "123456789", "dob": "1990-01-01", "age": 28})
    data = response.get_json()

    assert response.status_code == 200
    assert data["success"] is False
    assert data["message"] == "Voter already registered."

# Test election creation (admin required)
def test_create_election(client):
    # Mock admin login
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    response = client.post('/create_election', json={"name": "Election 2024", "start_date": "2024-05-01T00:00:00", "end_date": "2024-05-10T23:59:59"})
    data = response.get_json()

    assert response.status_code == 200
    assert data["success"] is True
    assert data["message"] == "Election created successfully."
    
    
def test_add_candidate(client):
    # Mock admin login
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Add a new candidate
    response = client.post('/add_candidate', json={
        "name": "Candidate A",
        "party": "Party X"
    })
    data = response.get_json()

    # Debug prints for response
    print("Response Status Code:", response.status_code)
    print("Response JSON:", data)

    # Assertions
    assert response.status_code == 200
    assert data["success"] is True
    assert data["message"] == "Candidate added successfully."



# Test: Delete an election
from bson import ObjectId



def test_delete_election(client):
    # Mock admin login
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Create a mock election
    election_data = {
        "name": "Election 2024",
        "start_date": "2024-05-01T00:00:00",
        "end_date": "2024-05-10T23:59:59"
    }
    result = mongo.db.elections.insert_one(election_data)
    election_id = str(result.inserted_id)  # Convert ObjectId to string for easier handling in tests

    # Confirm election exists in the database before deletion
    election = mongo.db.elections.find_one({"_id": ObjectId(election_id)})
    assert election is not None, "Election not found in database before deletion."

    # Delete the election
    response = client.delete(f'/delete_election/{election_id}')
    data = response.get_json()

    # Debug prints for response
    print("Response Status Code:", response.status_code)
    print("Response JSON:", data)

    # Assertions
    assert response.status_code == 200
    assert data["success"] is True
    assert data["message"] == "Election deleted successfully."

    # Verify election no longer exists after deletion
    election = mongo.db.elections.find_one({"_id": ObjectId(election_id)})
    assert election is None, "Election was not deleted."

