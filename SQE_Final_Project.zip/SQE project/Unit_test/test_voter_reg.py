import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pytest
from unittest.mock import patch, MagicMock
from app import app  # Assuming your Flask app is in app.py

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

@patch('app.mongo')  # Mock the mongo database
def test_register_voter(mock_mongo, client):
    # Mock MongoDB collections
    voters_collection = MagicMock()
    admins_collection = MagicMock()
    mock_mongo.db.voters = voters_collection
    mock_mongo.db.admins = admins_collection

    # Test case 1: Voter already registered
    voters_collection.find_one.return_value = {"cnic": "1234567890123"}
    response = client.post('/register_voter', json={
    "name": "John Doe",
    "cnic": "1234567890123",
    "dob": "2000-01-01",
    "age": 25
})
    assert response.status_code == 302  # Expecting a redirect
    assert '/login_page' in response.location  # Check if the redirect is going to the login page


   # Test case 2: Voter underage
    voters_collection.find_one.return_value = None  # No existing voter
    response = client.post('/register_voter', json={
    "name": "Jane Doe",
    "cnic": "9876543210987",
    "dob": "2010-01-01",
    "age": 15
})
    assert response.status_code == 302  # Expecting a redirect due to underage voter
    assert '/login_page' in response.location  # Check if the redirect is going to the login page


   # Test case 3: Successful registration
#     voters_collection.find_one.return_value = None  # No existing voter
#     response = client.post('/register_voter', json={
#     "name": "Alice",
#     "cnic": "5678901234567",
#     "dob": "1990-01-01",
#     "age": 30
# })
    assert response.status_code == 302  # Expecting a redirect after successful registration
    assert '/login_page' in response.location  # Check if the redirect is going to the login page


    # Test case 4: Access without admin privileges
    with patch('app.session', {'user': {'role': 'user'}}):  # Non-admin user
        response = client.post('/register_voter', json={
            "name": "Bob",
            "cnic": "6543210987654",
            "dob": "1995-01-01",
            "age": 28
        })
        assert response.status_code == 302  # Redirect to login
        assert '/login_page' in response.location
