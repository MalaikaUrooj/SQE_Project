import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from flask import Flask, jsonify
from flask_pymongo import PyMongo
from datetime import datetime,timedelta

from bson import ObjectId
from app import app, mongo, format_response  # import your Flask app

# Set up the test configuration
@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['MONGO_URI'] = 'mongodb://localhost:27017/test_evoting'  # use a separate test database
    client = app.test_client()
    with app.app_context():
        # Initialize the database or reset it for tests
        mongo.db.voters.drop()
        mongo.db.admins.drop()
        mongo.db.candidates.drop()
        mongo.db.elections.drop()
    yield client
    # Cleanup after tests
    mongo.db.voters.drop()
    mongo.db.admins.drop()
    mongo.db.candidates.drop()
    mongo.db.elections.drop()
    
def test_vote_count_and_winner_declaration(client):
    # Mock admin login and create candidates
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    candidate1 = mongo.db.candidates.insert_one({"name": "Candidate 1", "party": "Party A"})
    candidate2 = mongo.db.candidates.insert_one({"name": "Candidate 2", "party": "Party B"})
    
    # Set election dates with a future end date
    election = mongo.db.elections.insert_one({
        "name": "Election 1", 
        "start_date": datetime.now(), 
        "end_date": datetime.now() + timedelta(days=1),  # Set the end date to a future time
        "votes": {}
    })
    
    # Mock voter login
    voter = mongo.db.voters.insert_one({
        "name": "Voter", 
        "cnic": "987654321", 
        "dob": "1990-01-01", 
        "age": 30, 
        "voted": False
    })
    client.post('/login', json={"cnic": "987654321", "dob": "1990-01-01"})
    
    # Cast votes for candidates
    client.post('/cast_vote', json={"election_id": str(election.inserted_id), "candidate_id": str(candidate1.inserted_id)})
    client.post('/cast_vote', json={"election_id": str(election.inserted_id), "candidate_id": str(candidate2.inserted_id)})
    client.post('/cast_vote', json={"election_id": str(election.inserted_id), "candidate_id": str(candidate1.inserted_id)})

    # Check the updated vote count after casting votes
    election_doc = mongo.db.elections.find_one({"_id": election.inserted_id})  # Fetch the election document
    print("Votes after casting: ", election_doc["votes"])  # Debug print to check vote counts

    # Check election results
    response = client.get(f'/get_results/{str(election.inserted_id)}')  # Pass the election ID as string
    data = response.get_json()

    print("Response data:", data)  # Add this to see the response content

    assert response.status_code == 200
    assert data["success"] is True
    assert "winner" in data["data"]
    assert data["data"]["winner"]["name"] == "Candidate 1"
    assert data["data"]["winner"]["votes"] == 1  # Candidate 1 should have 2 votes
def test_no_votes_cast(client):
    # Mock admin login and create a candidate
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    candidate1 = mongo.db.candidates.insert_one({"name": "Candidate 1", "party": "Party A"})
    election = mongo.db.elections.insert_one({
        "name": "Election 1", 
        "start_date": datetime.now(), 
        "end_date": datetime.now(),
        "votes": {}
    })

    # Check election results when no votes are cast
    response = client.get(f'/get_results/{election.inserted_id}')
    data = response.get_json()

    assert response.status_code == 200
    assert data["success"] is False
    assert data["message"] == "No votes cast yet."


def test_invalid_election_id_for_results(client):
    # Mock admin login
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Attempt to get results for a non-existent election
    invalid_election_id = "605c72ef1532073e741bb1c1"  # Example invalid ID
    response = client.get(f'/get_results/{invalid_election_id}')
    data = response.get_json()

    assert response.status_code == 404
    assert data["success"] is False
    assert data["message"] == "Election not found."
def test_available_elections(client):
    # Mock admin login
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Insert an election with a start date in the past and end date in the future
    start_date = datetime.now() - timedelta(days=1)  # 1 day in the past
    end_date = datetime.now() + timedelta(days=1)  # 1 day in the future
    mongo.db.elections.insert_one({"name": "Election 2024", "start_date": start_date, "end_date": end_date, "votes": {}})
    
    # Test available elections
    response = client.get('/available_elections')
    data = response.get_json()
    
    print(data)  # Print the response data to check

    assert response.status_code == 200
    assert data["success"] is True
    assert len(data["data"]) > 0  # Ensure elections are returned
    assert "election_id" in data["data"][0]

