import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from app import app, mongo
from flask import jsonify, session
from datetime import datetime, timedelta
from bson import ObjectId
from urllib.parse import urlparse
@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['MONGO_URI'] = 'mongodb://localhost:27017/test_evoting'  # Use a separate test database
    client = app.test_client()
    with app.app_context():
        # Initialize the database or reset it for tests
        mongo.db.voters.drop()
        mongo.db.admins.drop()
        mongo.db.candidates.drop()
        mongo.db.elections.drop()
    yield client
    # Cleanup after tests
    mongo.db.voters.drop()
    mongo.db.admins.drop()
    mongo.db.candidates.drop()
    mongo.db.elections.drop()

def test_cast_vote(client):
    # Setup: Insert necessary data into DB
    voter_data = {"name": "John Doe", "cnic": "12345", "dob": "2000-01-01", "age": 24, "voted": False}
    voter = mongo.db.voters.insert_one(voter_data)
    
    candidate_data = {"name": "Candidate A", "party": "Party X"}
    candidate = mongo.db.candidates.insert_one(candidate_data)

    # Set up a valid election with start and end times
    current_time = datetime.now()
    election_data = {
        "name": "Election 2024", 
        "start_date": current_time - timedelta(minutes=5),  # Start time in the past
        "end_date": current_time + timedelta(minutes=5),    # End time in the future
        "votes": {}
    }
    election = mongo.db.elections.insert_one(election_data)

    # Simulate login by setting session
    with client.session_transaction() as sess:
        sess['user'] = {"id": str(voter.inserted_id), "role": "voter"}

    # Request: Cast vote
    response = client.post('/cast_vote', json={
        "election_id": str(election.inserted_id),
        "candidate_id": str(candidate.inserted_id)
    })
    
    # Assertions
    assert response.status_code == 200
    assert response.json['success'] is True
    assert response.json['message'] == "Vote cast successfully."

def test_cast_vote_invalid_voter(client):
    # Step 1: Simulate login for the voter (use a CNIC that is not in the voters collection)
    login_response = client.post('/login', json={
        'cnic': 'invalid_cnic',  # Invalid CNIC for login
        'dob': '1990-01-01'  # Invalid DOB or any combination that will fail
    })
    
    # Step 2: Ensure login failed (you can verify this based on the response)
    login_json = login_response.get_json()
    assert login_json['success'] == False
    assert login_json['message'] == "Invalid credentials"

    # Step 3: Attempt to cast a vote with an invalid voter ID
    response = client.post('/cast_vote', json={
        "election_id": "some_valid_election_id",  # Use a valid election ID
        "candidate_id": "some_valid_candidate_id"  # Use a valid candidate ID
    })

    # Step 4: Check that the response is a 302 redirect (as the user is not logged in)
    assert response.status_code == 302  # Should redirect to login page

    # Step 5: Check if the response redirects to the login page (only check the relative URL)
    assert response.location == 'http://localhost/login_page'  # Compare only the path, not the full URL





def test_cast_vote_already_voted(client):
    # Setup: Insert a voter who has already voted
    voter_data = {"name": "John Doe", "cnic": "12345", "dob": "2000-01-01", "age": 24, "voted": True}
    voter = mongo.db.voters.insert_one(voter_data)

    candidate_data = {"name": "Candidate A", "party": "Party X"}
    candidate = mongo.db.candidates.insert_one(candidate_data)

    election_data = {
        "name": "Election 2024", 
        "start_date": datetime.now() - timedelta(minutes=5), 
        "end_date": datetime.now() + timedelta(minutes=5),
        "votes": {}
    }
    election = mongo.db.elections.insert_one(election_data)

    # Simulate login by setting session
    with client.session_transaction() as sess:
        sess['user'] = {"id": str(voter.inserted_id), "role": "voter"}

    # Request: Cast vote
    response = client.post('/cast_vote', json={
        "election_id": str(election.inserted_id),
        "candidate_id": str(candidate.inserted_id)
    })

    # Assertions: Voter has already voted, should fail
    assert response.status_code == 200
    assert response.json['success'] is False
    assert response.json['message'] == "Voter has already cast a vote."
