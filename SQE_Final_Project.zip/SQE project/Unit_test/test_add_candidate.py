import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pytest
from unittest.mock import MagicMock, patch
from app import app, mongo

@pytest.fixture
def client():
    # Create a test client for Flask
    with app.test_client() as client:
        yield client

@pytest.fixture
def mock_admin_required():
    """Mock the admin_required decorator for testing"""
    with patch('app.admin_required') as mock_decorator:
        mock_decorator.return_value = lambda x: x  # Directly call the function
        yield mock_decorator

# Test candidate management - Add candidate
@patch('app.mongo')
def test_add_candidate(mock_mongo, client, mock_admin_required):
    # Mock the database collections
    candidates_collection = MagicMock()
    mock_mongo.db.candidates = candidates_collection
    
    # Scenario 1: Candidate doesn't exist
    candidates_collection.find_one.return_value = None  # No existing candidate

    # Mock admin session
    with client.session_transaction() as session:
        session['user'] = {'role': 'admin'}

    # Send request to add a new candidate
    response = client.post('/add_candidate', json={
        'name': 'Alice',
        'party': 'Party A'
    })
    
    # Check if candidate is added
    candidates_collection.insert_one.assert_called_once_with({
        'name': 'Alice',
        'party': 'Party A'
    })
    assert response.json['success'] == True
    assert response.json['message'] == "Candidate added successfully."

# Test duplicate candidate handling
@patch('app.mongo')
def test_add_duplicate_candidate(mock_mongo, client, mock_admin_required):
    # Mock the database collections
    candidates_collection = MagicMock()
    mock_mongo.db.candidates = candidates_collection

    # Scenario 2: Candidate already exists
    candidates_collection.find_one.return_value = {"name": "Alice", "party": "Party A"}  # Candidate exists

    # Mock admin session
    with client.session_transaction() as session:
        session['user'] = {'role': 'admin'}

    # Send request to add an existing candidate
    response = client.post('/add_candidate', json={
        'name': 'Alice',
        'party': 'Party A'
    })

    # Check if the candidate is not added again
    candidates_collection.insert_one.assert_not_called()
    assert response.json['success'] == False
    assert response.json['message'] == "Candidate already exists."

# Test admin_required decorator - not admin
@patch('app.mongo')
def test_add_candidate_not_admin(mock_mongo, client):
    # Mock the database collections
    candidates_collection = MagicMock()
    mock_mongo.db.candidates = candidates_collection

    # Scenario 3: User is not an admin
    with client.session_transaction() as session:
        session['user'] = {'role': 'user'}  # Non-admin user

    # Send request to add a candidate
    response = client.post('/add_candidate', json={
        'name': 'Alice',
        'party': 'Party A'
    })

    # Assert that the user is redirected to the login page
    assert response.status_code == 302  # Redirect
    assert 'login_page' in response.location  # Check if 'login_page' is in the string



# Test if admin user is created if not already present
# @patch('app.mongo')
# @patch('app.create_admin')
# def test_create_admin(mock_create_admin, mock_mongo):
#     # Mock the admins collection
#     admins_collection = MagicMock()
#     mock_mongo.db.admins = admins_collection

#     # Scenario: Admin doesn't exist in the database
#     admins_collection.find_one.return_value = None  # No existing admin

#     # Call the function to create admin
#     with patch('app.create_admin') as create_admin_func:
#         create_admin_func()

#     # Ensure that create_admin is called (it should be called once)
#     mock_create_admin.assert_called_once()

#     # Check if admin was inserted
#     admins_collection.insert_one.assert_called_once_with({
#         "admin_id": "admin",
#         "name": "Admin",
#         "cnic": "admin_cnic",
#         "dob": "1970-01-01"
#     })

