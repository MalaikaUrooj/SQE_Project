import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from flask import Flask, jsonify
from flask_pymongo import PyMongo
from datetime import datetime
from bson import ObjectId
from app import app, mongo, format_response  # import your Flask app
from datetime import datetime, timedelta
# Set up the test configuration
@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['MONGO_URI'] = 'mongodb://localhost:27017/test_evoting'  # use a separate test database
    client = app.test_client()
    with app.app_context():
        # Initialize the database or reset it for tests
        mongo.db.voters.drop()
        mongo.db.admins.drop()
        mongo.db.candidates.drop()
        mongo.db.elections.drop()
    yield client
    # Cleanup after tests
    mongo.db.voters.drop()
    mongo.db.admins.drop()
    mongo.db.candidates.drop()
    mongo.db.elections.drop()
def test_admin_can_create_election(client):
    # Login as admin
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})
    
    # Attempt to create an election
    response = client.post('/create_election', json={
        "name": "Test Election",
        "start_date": "2024-01-01T00:00:00",
        "end_date": "2024-01-02T00:00:00"
    })
    
    assert response.status_code == 200
    assert response.get_json()["success"] is True

def test_voter_cannot_create_election(client):
    # Login as voter
    mongo.db.voters.insert_one({"name": "Voter", "cnic": "voter_cnic", "dob": "1990-01-01", "age": 30})
    client.post('/login', json={"cnic": "voter_cnic", "dob": "1990-01-01"})
    
    # Attempt to create an election
    response = client.post('/create_election', json={
        "name": "Test Election",
        "start_date": "2024-01-01T00:00:00",
        "end_date": "2024-01-02T00:00:00"
    })
    
    assert response.status_code == 302  # Forbidden
    assert response.headers['Location'] == 'http://localhost/login_page'
    
    
def test_cast_vote(client):
    # Setup: Insert necessary data into DB
    voter_data = {"name": "John Doe", "cnic": "12345", "dob": "2000-01-01", "age": 24, "voted": False}
    voter = mongo.db.voters.insert_one(voter_data)
    
    candidate_data = {"name": "Candidate A", "party": "Party X"}
    candidate = mongo.db.candidates.insert_one(candidate_data)

    # Set up a valid election with start and end times
    current_time = datetime.now()
    election_data = {
        "name": "Election 2024", 
        "start_date": current_time - timedelta(minutes=5),  # Start time in the past
        "end_date": current_time + timedelta(minutes=5),    # End time in the future
        "votes": {}
    }
    election = mongo.db.elections.insert_one(election_data)

    # Simulate login by setting session
    with client.session_transaction() as sess:
        sess['user'] = {"id": str(voter.inserted_id), "role": "voter"}

    # Request: Cast vote
    response = client.post('/cast_vote', json={
        "election_id": str(election.inserted_id),
        "candidate_id": str(candidate.inserted_id)
    })
    
    # Assertions
    assert response.status_code == 200
    assert response.json['success'] is True
    assert response.json['message'] == "Vote cast successfully."




def test_admin_can_add_candidate(client):
    # Mock admin login
    mongo.db.admins.insert_one({"admin_id": "admin", "cnic": "admin_cnic", "dob": "1970-01-01"})
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Add a new candidate
    response = client.post('/add_candidate', json={
        "name": "Candidate A",
        "party": "Party X"
    })
    data = response.get_json()

    # Debug prints for response
    print("Response Status Code:", response.status_code)
    print("Response JSON:", data)

    # Assertions
    assert response.status_code == 200
    assert data["success"] is True
    assert data["message"] == "Candidate added successfully."


