import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from app import app, mongo
from flask import jsonify
from bson import ObjectId

@pytest.fixture
def client():
    app.config['TESTING'] = True
    client = app.test_client()
    yield client

def test_login_voter(client):
    # Setup: Insert a voter into the database
    voter_data = {"name": "John Doe", "cnic": "12345", "dob": "2000-01-01", "age": 24, "voted": False}
    mongo.db.voters.insert_one(voter_data)

    # Request: Login with correct credentials
    response = client.post('/login', json={"cnic": "12345", "dob": "2000-01-01"})
    
    # Assertions
    assert response.status_code == 200
    assert response.json['success'] is True
    assert response.json['data']['role'] == 'voter'

def test_login_invalid(client):
    # Request: Login with invalid credentials
    response = client.post('/login', json={"cnic": "wrong_cnic", "dob": "2000-01-01"})
    
    # Assertions
    assert response.status_code == 200
    assert response.json['success'] is False
    assert response.json['message'] == "Invalid credentials"
    
def test_unauthorized_access(client):
    # Attempt to access a protected route without being authenticated
    response = client.post('/cast_vote')  # Use POST if that's the correct method for this route
    
    # Assertions for redirection
    assert response.status_code == 302  # Check for redirection
    assert 'Location' in response.headers  # Ensure redirection header is present
    assert '/login' in response.headers['Location']  # Verify redirection to login page (or appropriate URL)
