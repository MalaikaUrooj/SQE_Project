"""
app.py
This module serves as the backend for the e-voting application. It is built using Flask
and includes configurations for MongoDB. The module handles user authentication, 
voter registration, candidate management, election scheduling, vote casting, 
and result analytics. 
It also provides API endpoints and templates for the application's functionality.
Endpoints include:
- User login and authentication
- Admin-specific features like voter and candidate management
- Election creation, deletion, and results retrieval
- Available elections and vote casting for registered users
"""
import os
from datetime import datetime
from functools import wraps
from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_pymongo import PyMongo
from bson import ObjectId
app = Flask(__name__)
app.secret_key = 'your_secret_key'
# Configure MongoDB
app.config["MONGO_URI"] = os.getenv("TEST_MONGO_URI", "mongodb://localhost:27017/evote")
app.config["MONGO_DBNAME"] = "evote"
mongo = PyMongo(app)
@app.route('/test_db')
def test_db():
    try:
        # Try to fetch a sample document from the voters collection
        voter = mongo.db.voters.find_one()
        if voter:
            return "MongoDB is connected, and data is accessible!"
        else:
            return "MongoDB is connected, but no data found."
    except Exception as e:
        return f"Error connecting to MongoDB: {e}"

def format_response(success, message, data=None):
    """
    Formats the response to be returned as a JSON object.

    Args:
        success (bool): Indicates whether the operation was successful.
        message (str): A message providing details about the operation's outcome.
        data (dict, optional): Additional data to include in the response. Defaults to None.

    Returns:
        Response: A Flask JSON response containing the success status, message, and data.
    """
    return jsonify({"success": success, "message": message, "data": data})

def login_required(f):
    """
    A decorator to ensure the user is logged in before accessing the decorated route.

    Args:
        f (function): The route function to be wrapped.

    Returns:
        function: The wrapped function that checks if the user is in the session.
                  If not logged in, redirects to the login page.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """
    A decorator to ensure the user is logged in and has the 'admin' role before
    accessing the decorated route.

    Args:
        f (function): The route function to be wrapped.

    Returns:
        function: The wrapped function that checks if the user is logged in
                  and has an 'admin' role. If not, redirects to the login page.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session or session['user']['role'] != 'admin':
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    return decorated_function
# Initialize admin user
@app.before_request
def create_admin():
    """
    Ensures that an admin user exists in the MongoDB database. If the admin user 
    does not exist, it creates a new admin with the default details.

    This function is called before each request to ensure that the admin is 
    initialized in the database. It checks if the MongoDB connection and the 
    'admins' collection exist, and if the admin user with a predefined 'cnic' 
    value is missing, it inserts a new record.

    Returns:
        None
    """
    admin = mongo.db.admins.find_one({"cnic": "admin_cnic"})
    if not admin:
        result = mongo.db.admins.insert_one({
            "admin_id": "admin",
            "name": "Admin",
            "cnic": "admin_cnic",
            "dob": "1970-01-01"
        })
        print("Admin inserted: ", result.inserted_id)  # Print inserted admin ID
# User Login
@app.route('/login', methods=['POST'])
def login():
    """
    Handles the user login process. It checks the provided credentials (CNIC and DOB)
    against the database to authenticate the user as either a voter or an admin. If 
    the credentials are valid, it stores the user session with their role ('voter' or 'admin').

    Request Data:
        - cnic (str): The CNIC of the user.
        - dob (str): The date of birth of the user.

    Response:
        Returns a JSON response indicating the success or failure of the login attempt.
        If the credentials are valid, the response contains the user's role.
        If invalid, the response contains an error message.

    Returns:
        jsonify: A response object with success or failure status and message.
    """
    data = request.json
    cnic = data.get('cnic')
    dob = data.get('dob')

    user = mongo.db.voters.find_one({"cnic": cnic, "dob": dob})
    if user:
        session['user'] = {"id": str(user['_id']), "role": "voter"}
        return format_response(True, "Login successful", {"role": "voter"})
    admin = mongo.db.admins.find_one({"cnic": cnic, "dob": dob})
    if admin:
        session['user'] = {"id": admin['admin_id'], "role": "admin"}
        return format_response(True, "Login successful", {"role": "admin"})
    return format_response(False, "Invalid credentials")
# Voter Registration
@app.route('/register_voter', methods=['POST'])
@admin_required
def register_voter():
    """
    Registers a new voter in the system. The function checks if the voter is already 
    registered and if the voter meets the minimum age requirement (18 years or older). 
    If both conditions are satisfied, the voter is added to the database.

    Request Data:
        - name (str): The name of the voter.
        - cnic (str): The CNIC of the voter.
        - dob (str): The date of birth of the voter.
        - age (int): The age of the voter.

    Response:
        Returns a JSON response indicating the success or failure of the registration process.
        If the voter is already registered or does not meet the age requirement, 
        the response contains an appropriate error message.
        If the registration is successful, the response confirms the successful registration.

    Returns:
        jsonify: A response object with success or failure status and message.
    """
    data = request.json
    name = data.get('name')
    cnic = data.get('cnic')
    dob = data.get('dob')
    age = data.get('age')

    if mongo.db.voters.find_one({"cnic": cnic}):
        return format_response(False, "Voter already registered.")
    if age < 18:
        return format_response(False, "Voter must be at least 18 years old.")

    mongo.db.voters.insert_one({"name": name, "cnic": cnic, "dob": dob, "age": age, "voted": False})
    return format_response(True, "Voter registered successfully.")
# Candidate Management
@app.route('/add_candidate', methods=['POST'])
@admin_required
def add_candidate():
    """
    Adds a new candidate to the system. The function checks if a candidate with the 
    same name and party already exists in the database. If not, the new candidate is 
    added to the candidates collection.

    Request Data:
        - name (str): The name of the candidate.
        - party (str): The political party of the candidate.

    Response:
        Returns a JSON response indicating the success or failure of the operation.
        If a candidate with the same name and party already exists, the response 
        contains an error message.
        If the candidate is added successfully, the response confirms the addition.

    Returns:
        jsonify: A response object with success or failure status and message.
    """
    data = request.json
    name = data.get('name')
    party = data.get('party')

    if mongo.db.candidates.find_one({"name": name, "party": party}):
        return format_response(False, "Candidate already exists.")

    mongo.db.candidates.insert_one({"name": name, "party": party})
    return format_response(True, "Candidate added successfully.")
# Election Scheduling
@app.route('/create_election', methods=['POST'])
@admin_required
def create_election():
    """
    Creates a new election in the system with a specified name, start date, and end date.
    The function checks if the start date is earlier than the end date. If the start date 
    is not earlier, it returns an error message.

    Request Data:
        - name (str): The name of the election.
        - start_date (str): The start date of the election in ISO 8601 format.
        - end_date (str): The end date of the election in ISO 8601 format.

    Response:
        Returns a JSON response indicating the success or failure of the operation.
        If the election dates are invalid (start date is not earlier than end date), 
        the response contains an error message.
        If the election is created successfully, the response confirms the creation.

    Returns:
        jsonify: A response object with success or failure status and message.
    """
    data = request.json
    name = data.get('name')
    start_date = datetime.fromisoformat(data.get('start_date'))
    end_date = datetime.fromisoformat(data.get('end_date'))

    if start_date >= end_date:
        return format_response(False, "Invalid election schedule.")

    # Insert the election and get the inserted ID
    election = {"name": name, "start_date": start_date, "end_date": end_date, "votes": {}}
    result = mongo.db.elections.insert_one(election)

    # Return the inserted election ID in the response
    return format_response(
        True,
        "Election created successfully.",
        {"election_id": str(result.inserted_id)}
    )
@app.route('/delete_election/<election_id>', methods=['DELETE'])
@admin_required
def delete_election(election_id):
    """
    Deletes an election from the system based on the provided election ID.

    Parameters:
        election_id (str): The unique identifier of the election to be deleted.

    Response:
        Returns a JSON response indicating whether the deletion was successful or not.
        If no election is found with the given ID, an error message is returned.
        If the election is successfully deleted, a success message is returned.

    Returns:
        jsonify: A response object with success or failure status and message.
    """
    try:
        # Ensure the election_id is converted to ObjectId
        election_id = ObjectId(election_id)
    except Exception as e:
        return format_response(False, "Invalid election ID.")

    # Attempt to delete the election from the database
    result = mongo.db.elections.delete_one({"_id": election_id})

    # Check if the election was deleted
    if result.deleted_count == 0:
        return format_response(False, "Election not found.")

    # Return success message if deletion was successful
    return format_response(True, "Election deleted successfully.")
# Vote Casting
@app.route('/cast_vote', methods=['POST'])
@login_required
def cast_vote():
    """
    Allows a registered voter to cast their vote in a specific election.

    This function checks if the user is an admin (who cannot vote), 
    verifies the voter's registration 
    status, checks if the election is active, and ensures that the candidate exists. 
    If all conditions 
    are met, the vote is cast, and the voter's 'voted' status is updated.

    Parameters:
        None (uses session to get voter ID and request JSON for election and candidate IDs).

    Response:
        Returns a JSON response indicating the success or failure of the voting process.
        The response includes messages such as:
        - If the user is an admin.
        - If the voter is not registered or has already voted.
        - If the election or candidate is not found.
        - If the election is not active.
        - If the vote is cast successfully.

    Returns:
        jsonify: A response object with success or failure status and a relevant message.
    """
    if session['user']['role'] == 'admin':
        return format_response(False, "Admins are not allowed to cast votes.")
    data = request.json
    voter_id = session['user']['id']
    election_id = data.get('election_id')
    candidate_id = data.get('candidate_id')
    try:
        # Convert voter_id to ObjectId (MongoDB's default for _id)
        voter = mongo.db.voters.find_one({"_id": ObjectId(voter_id)})
    except Exception as e:
        return format_response(False, "Invalid voter ID format.")
    if not voter:
        return format_response(False, "Voter not registered.")
    if voter.get('voted'):
        return format_response(False, "Voter has already cast a vote.")
    election = mongo.db.elections.find_one({"_id": ObjectId(election_id)})
    print(election)
    if not election:
        return format_response(False, "Election not found.")
    candidate = mongo.db.candidates.find_one({"_id": ObjectId(candidate_id)})
    if not candidate:
        return format_response(False, "Candidate not found.")
    current_time = datetime.now()
    if current_time < election['start_date'] or current_time > election['end_date']:
        return format_response(False, "Election is not active.")
    votes = election.get('votes', {})
    votes[candidate_id] = votes.get(candidate_id, 0) + 1
    mongo.db.elections.update_one({"_id": ObjectId(election_id)}, {"$set": {"votes": votes}})
    mongo.db.voters.update_one({"_id": ObjectId(voter_id)}, {"$set": {"voted": True}})
    return format_response(True, "Vote cast successfully.")
# Results and Analytics
@app.route('/get_results/<election_id>', methods=['GET'])
@login_required
def get_results(election_id):
    """
    Retrieves the results of a specific election, including the vote count for each candidate
    and the winner.

    This function fetches the election details, 
    including the vote counts for each candidate.
    It calculates the winner by 
    identifying the candidate with the highest number of votes.
    If no votes have been cast, 
    the function returns a message indicating that no votes have been 
    cast yet.

    Parameters:
        election_id (str): 
        The unique identifier of the election for which results are being requested.

    Returns:
        jsonify: A response object with the election results, 
                including the vote count for each candidate 
                and details about the winning candidate. 
                If the election is not found or no votes have been 
                cast, an error message is returned.

    Response format:
        - If election is found, and votes are cast, 
          returns the results with the winner.
        - If election is not found, 
          returns a message indicating the election doesn't exist.
        - If no votes have been cast, 
           returns a message indicating no votes have been cast yet.
    """
    try:
        # Convert election_id to ObjectId
        election = mongo.db.elections.find_one({"_id": ObjectId(election_id)})
    except Exception as e:
        return format_response(False, "Invalid election ID format."), 400  # Return 400 for invalid format
    if not election:
        return format_response(False, "Election not found."), 404  # Return 404 when the election is not found
    votes = election.get('votes', {})
    if not votes:
        return format_response(False, "No votes cast yet."), 200  # You can leave this as 200 for no votes yet
    # Find the candidate with the maximum votes
    winner_id = max(votes, key=votes.get)
    winner = mongo.db.candidates.find_one({"_id": ObjectId(winner_id)})
    return format_response(True, "Results retrieved successfully.", {
        "results": votes,
        "winner": {
            "candidate_id": winner_id,
            "name": winner['name'],
            "votes": votes[winner_id]
        }
    }), 200  # Return 200 for successful result retrieval
@app.route('/available_elections', methods=['GET'])
@login_required
def available_elections():
    """
    Retrieves a list of elections that are currently 
    ongoing based on the current date and time.

    This function fetches all elections from the database that are currently active.
    An election is considered
    active if its start date is before or equal to the current date and 
    its end date is after or equal to the 
    current date.

    Returns:
        jsonify: A response object with a list of available elections, 
        including their unique election ID and name.
        If no ongoing elections are found, an empty list is returned.

    Response format:
        - If elections are found, returns a list of ongoing elections.
        - If no elections are found, returns an empty list of elections.
    """
    current_time = datetime.now()
    elections = mongo.db.elections.find({"start_date": 
    {"$lte": current_time}, "end_date": {"$gte": current_time}})
    election_list = [{"election_id": str(election["_id"]), 
    "name": election["name"]} for election in elections]
    return format_response(True, "Available elections retrieved successfully.", election_list)
@app.route('/')
@login_required
def home():
    """
    Renders the home page of the application.

    This function handles the request to the home route ('/') 
    and renders the 'index.html' template. It doesn't
    require any parameters and simply returns the rendered HTML page to the user.

    Returns:
        Response: The rendered 'index.html' template, 
        which represents the homepage of the application.
    """
    return render_template('index.html')
@app.route('/login_page')
def login_page():
    """
    Renders the login page of the application.

    This function handles the request to the login route ('/login') 
    and renders the 'login.html' template. 
    It doesn't require any parameters 
    and simply returns the rendered HTML page for the user to log in.

    Returns:
        Response: The rendered 'login.html' template, 
        which represents the login page of the application.
    """
    return render_template('login.html')
@app.route('/get_candidates', methods=['GET'])
def get_candidates():
    # Fetch candidates from the database
    candidates = mongo.db.candidates.find()

    # Convert ObjectId to string and prepare the response
    candidates_list = [
        {
            "candidate_id": str(candidate["_id"]),  # Convert ObjectId to string
            "name": candidate["name"],
            "party": candidate["party"]
        }
        for candidate in candidates
    ]

    return jsonify({"success": True, "data": candidates_list})
if __name__ == '__main__':
    app.run(debug=True)
