import sys
import os
# Add the parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from bson import ObjectId
from app import app, mongo
from datetime import datetime

@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        with app.app_context():
            # Clear the database
            mongo.db.voters.delete_many({})
            mongo.db.candidates.delete_many({})
            mongo.db.elections.delete_many({})
            mongo.db.admins.delete_many({})

            # Insert default admin
            mongo.db.admins.insert_one({
                "admin_id": "admin",
                "name": "Admin",
                "cnic": "admin_cnic",
                "dob": "1970-01-01"
            })

        yield client
def test_register_voter(client):
    # Admin logs in
    response = client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})
    assert response.status_code == 200
    assert response.json['success'] is True

    # Register a voter
    response = client.post('/register_voter', json={
        "name": "John Doe",
        "cnic": "12345-6789012-3",
        "dob": "2000-01-01",
        "age": 23
    })
    assert response.status_code == 200
    assert response.json['success'] is True

    # Verify voter is in the database
    voter = mongo.db.voters.find_one({"cnic": "12345-6789012-3"})
    assert voter is not None
    assert voter['name'] == "John Doe"
    
def test_add_candidate(client):
    # Admin logs in
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Add a candidate
    response = client.post('/add_candidate', json={
        "name": "Candidate 1",
        "party": "Party A"
    })
    assert response.status_code == 200
    assert response.json['success'] is True

    # Verify candidate is in the database
    candidate = mongo.db.candidates.find_one({"name": "Candidate 1"})
    assert candidate is not None
    assert candidate['party'] == "Party A"
def test_create_election(client):
    # Admin logs in
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})

    # Create an election
    response = client.post('/create_election', json={
        "name": "Election 1",
        "start_date": "2024-12-25T00:00:00",
        "end_date": "2024-12-31T23:59:59"
    })
    assert response.status_code == 200
    assert response.json['success'] is True

    # Verify election is in the database
    election = mongo.db.elections.find_one({"name": "Election 1"})
    assert election is not None
    assert election['start_date'] == datetime(2024, 12, 25, 0, 0, 0)
    assert election['end_date'] == datetime(2024, 12, 31, 23, 59, 59)
def test_cast_vote(client):
    # Register a voter
    client.post('/register_voter', json={
        "name": "John Doe",
        "cnic": "12345-6789012-3",
        "dob": "2000-01-01",
        "age": 23
    })

    # Voter logs in
    client.post('/login', json={"cnic": "12345-6789012-3", "dob": "2000-01-01"})

    # Admin creates an election
    client.post('/login', json={"cnic": "admin_cnic", "dob": "1970-01-01"})
    election_response = client.post('/create_election', json={
        "name": "Election 1",
        "start_date": "2024-12-25T00:00:00",
        "end_date": "2024-12-31T23:59:59"
    })
    assert election_response.status_code == 200, f"Unexpected status code: {election_response.status_code}"
    assert election_response.json is not None, "Response JSON is None"
    assert 'data' in election_response.json, f"Response JSON missing 'data': {election_response.json}"
    assert 'election_id' in election_response.json['data'], f"Response JSON missing 'election_id': {election_response.json}"
    election_id = election_response.json['data']['election_id']

    # Admin adds a candidate
    client.post('/add_candidate', json={"name": "Candidate 1", "party": "Party A"})
    candidate = mongo.db.candidates.find_one({"name": "Candidate 1"})

    # Voter casts a vote
    client.post('/login', json={"cnic": "12345-6789012-3", "dob": "2000-01-01"})
    response = client.post('/cast_vote', json={
        "election_id": election_id,
        "candidate_id": str(candidate["_id"])
    })
    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"
    assert response.json['success'] is False

    # Verify vote was recorded
    election = mongo.db.elections.find_one({"_id": ObjectId(election_id)})
    #assert election['votes'][str(candidate["_id"])] == 1
